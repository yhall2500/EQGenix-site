- **JavaScript** — vanilla JS, no frameworks, no dependencies
- **Google Fonts** — Playfair Display, Outfit, Space Mono

## Design System

- **Palette:** Dark slate, brushed gold, silver, stone gray
- **Typography:** Playfair Display (serif headings), Outfit (sans body), Space Mono (labels)
- **Aesthetic:** Private wealth advisory / institutional think-tank

## Trademarks

Built, Not Downloaded™, Emotional Portfolio™, Mission-Ready Civilian™, ASCEND™, Grit to Genius™, Mentor to Men™, and The Sovereign Workforce Program™ are trademarks of EQGenix Inc.

© EQGenix Inc. All rights reserved.
